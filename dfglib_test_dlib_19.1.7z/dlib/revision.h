#ifndef DLIB_REVISION_H
// Version:  19.1
// Date:     Sat Aug 13 14:07:31 EDT 2016
// Mercurial Revision ID:  ae1979942c0c
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  1
#define DLIB_PATCH_VERSION  0
#endif
